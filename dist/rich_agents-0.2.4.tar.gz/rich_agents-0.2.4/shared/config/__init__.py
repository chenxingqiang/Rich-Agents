"""
Rich-Agents 配置管理模块
"""

from .rich_agents_config_manager import RichAgentsConfigManager

__all__ = ["RichAgentsConfigManager"]
