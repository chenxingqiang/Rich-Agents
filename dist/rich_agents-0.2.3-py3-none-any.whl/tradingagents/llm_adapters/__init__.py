# LLM Adapters for TradingAgents
from .dashscope_adapter import ChatDashScope

__all__ = ["ChatDashScope"]
